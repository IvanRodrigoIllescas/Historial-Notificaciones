package com.iridev.HistorialNotificaciones;

import android.content.ComponentName;
import android.content.Intent;
import android.provider.Settings;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Verificar si el servicio está activo
        if (!isNotificationServiceEnabled()) {
            // Si el servicio no está habilitado, redirige al usuario a la configuración para habilitarlo
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        }

        // Iniciar el servicio CustomNotificationListener
        startNotificationListenerService();
    }

    private void startNotificationListenerService() {
        Intent intent = new Intent(this, CustomNotificationListener.class);
        startService(intent);
    }

    private boolean isNotificationServiceEnabled() {
        ComponentName cn = new ComponentName(this, CustomNotificationListener.class);
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(cn.flattenToString());
    }
}
