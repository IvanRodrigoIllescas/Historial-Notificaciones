package com.iridev.HistorialNotificaciones;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

public class CustomNotificationListener extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        // Se invoca cuando una nueva notificación llega al sistema
        Log.d("NotificationListener", "Nueva notificación: " + sbn.getNotification().tickerText);

        // Aquí puedes realizar acciones con la notificación recibida, como guardarla, procesarla, etc.
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // Se invoca cuando una notificación es removida
        Log.d("NotificationListener", "Notificación removida: " + sbn.getNotification().tickerText);
    }
}
